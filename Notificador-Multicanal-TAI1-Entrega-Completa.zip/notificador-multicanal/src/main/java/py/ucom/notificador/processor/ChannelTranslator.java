package py.ucom.notificador.processor;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

public class ChannelTranslator implements Processor {
    private final ObjectMapper mapper = new ObjectMapper();

    @Override
    public void process(Exchange exchange) throws Exception {
        String body = exchange.getMessage().getBody(String.class);
        JsonNode input = mapper.readTree(body);
        String channel = exchange.getMessage().getHeader("channel", String.class);
        ObjectNode output = mapper.createObjectNode();
        output.put("notificationId", input.path("id").asText());
        output.put("recipient", input.path("recipient").asText());
        output.put("channel", channel);
        output.put("subject", input.path("subject").asText("Notificación"));
        output.put("content", input.path("message").asText());
        output.put("provider", switch (channel) {
            case "SMS" -> "SIMULATED-SMS-PROVIDER";
            case "EMAIL" -> "SIMULATED-EMAIL-PROVIDER";
            case "PUSH" -> "SIMULATED-PUSH-PROVIDER";
            default -> "UNKNOWN";
        });
        exchange.getMessage().setBody(mapper.writeValueAsString(output));
    }
}
