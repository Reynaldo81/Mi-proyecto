package py.ucom.notificador.model;

public record Notification(
        String id,
        String recipient,
        String channel,
        String subject,
        String message
) {}
