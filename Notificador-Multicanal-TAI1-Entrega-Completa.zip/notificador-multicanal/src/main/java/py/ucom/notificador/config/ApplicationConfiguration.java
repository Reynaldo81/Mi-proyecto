package py.ucom.notificador.config;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.activemq.artemis.jms.client.ActiveMQConnectionFactory;
import org.apache.camel.component.jms.JmsComponent;
import org.apache.camel.main.Main;
import py.ucom.notificador.route.NotificationRoute;
import py.ucom.notificador.route.DeliveryRoutes;
import py.ucom.notificador.route.ErrorRoute;

import javax.sql.DataSource;

public final class ApplicationConfiguration {
    private ApplicationConfiguration() {}

    public static void configure(Main main) {
        String brokerUrl = env("ARTEMIS_URL", "tcp://localhost:61616");
        String brokerUser = env("ARTEMIS_USER", "admin");
        String brokerPassword = env("ARTEMIS_PASSWORD", "admin");
        ActiveMQConnectionFactory cf = new ActiveMQConnectionFactory(brokerUrl, brokerUser, brokerPassword);

        JmsComponent jms = JmsComponent.jmsComponent(cf);
        jms.setConcurrentConsumers(2);
        main.bind("jms", jms);

        HikariConfig hikari = new HikariConfig();
        hikari.setJdbcUrl(env("DB_URL", "jdbc:postgresql://localhost:5432/notificaciones"));
        hikari.setUsername(env("DB_USER", "notificador"));
        hikari.setPassword(env("DB_PASSWORD", "notificador"));
        hikari.setMaximumPoolSize(5);
        DataSource dataSource = new HikariDataSource(hikari);
        main.bind("dataSource", dataSource);

        main.configure().addRoutesBuilder(new NotificationRoute());
        main.configure().addRoutesBuilder(new DeliveryRoutes());
        main.configure().addRoutesBuilder(new ErrorRoute());
    }

    private static String env(String name, String defaultValue) {
        String value = System.getenv(name);
        return value == null || value.isBlank() ? defaultValue : value;
    }
}
