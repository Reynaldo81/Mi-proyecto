package py.ucom.notificador;

import org.apache.camel.main.Main;
import py.ucom.notificador.config.ApplicationConfiguration;

public class Main {
    public static void main(String[] args) throws Exception {
        Main main = new Main();
        ApplicationConfiguration.configure(main);
        main.run(args);
    }
}
