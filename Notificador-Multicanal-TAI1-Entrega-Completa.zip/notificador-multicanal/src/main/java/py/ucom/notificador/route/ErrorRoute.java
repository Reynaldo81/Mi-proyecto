package py.ucom.notificador.route;

import org.apache.camel.builder.RouteBuilder;

public class ErrorRoute extends RouteBuilder {
    @Override
    public void configure() {
        from("jms:queue:notification.dlq")
            .routeId("dead-letter-handler")
            .process(e -> System.err.println("[DLQ] Mensaje rechazado: " + e.getMessage().getBody(String.class)))
            .to("sql:INSERT INTO notification_history(notification_id, channel, recipient, status, payload) VALUES (:#notificationId, :#channel, :#recipient, 'REJECTED', :#body)");
    }
}
