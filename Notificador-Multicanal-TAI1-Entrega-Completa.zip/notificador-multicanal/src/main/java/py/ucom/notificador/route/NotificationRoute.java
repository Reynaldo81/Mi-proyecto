package py.ucom.notificador.route;

import org.apache.camel.builder.RouteBuilder;
import py.ucom.notificador.processor.ValidationProcessor;

public class NotificationRoute extends RouteBuilder {
    @Override
    public void configure() {
        onException(IllegalArgumentException.class)
            .handled(true)
            .setHeader("errorType", constant("VALIDATION"))
            .to("jms:queue:notification.dlq")
            .setBody(simple("{\"status\":\"REJECTED\",\"reason\":\"${exception.message}\"}"));

        restConfiguration().component("platform-http").port(8080);

        rest("/notifications")
            .post()
            .consumes("application/json")
            .produces("application/json")
            .to("direct:submit");

        from("direct:submit")
            .routeId("notification-submit")
            .process(new ValidationProcessor())
            .setHeader("submittedAt", simple("${date:now:yyyy-MM-dd'T'HH:mm:ssXXX}"))
            .to("jms:queue:notification.input")
            .setBody(simple("{\"status\":\"ACCEPTED\",\"notificationId\":\"${header.notificationId}\"}"));

        from("jms:queue:notification.input")
            .routeId("notification-routing")
            .choice()
                .when(header("channel").isEqualTo("SMS")).to("direct:translate-sms")
                .when(header("channel").isEqualTo("EMAIL")).to("direct:translate-email")
                .when(header("channel").isEqualTo("PUSH")).to("direct:translate-push")
                .otherwise().to("jms:queue:notification.dlq");

        from("direct:translate-sms").to("direct:translate");
        from("direct:translate-email").to("direct:translate");
        from("direct:translate-push").to("direct:translate");

        from("direct:translate")
            .process(new py.ucom.notificador.processor.ChannelTranslator())
            .choice()
                .when(header("channel").isEqualTo("SMS")).to("jms:queue:notification.sms")
                .when(header("channel").isEqualTo("EMAIL")).to("jms:queue:notification.email")
                .when(header("channel").isEqualTo("PUSH")).to("jms:queue:notification.push")
                .otherwise().to("jms:queue:notification.dlq");
    }
}
