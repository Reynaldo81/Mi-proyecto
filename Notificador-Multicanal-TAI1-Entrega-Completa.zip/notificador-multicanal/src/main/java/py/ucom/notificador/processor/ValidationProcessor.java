package py.ucom.notificador.processor;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import py.ucom.notificador.model.Notification;

public class ValidationProcessor implements Processor {
    private final ObjectMapper mapper = new ObjectMapper();

    @Override
    public void process(Exchange exchange) throws Exception {
        String body = exchange.getMessage().getBody(String.class);
        Notification n = mapper.readValue(body, Notification.class);
        if (n.id() == null || n.id().isBlank()) throw new IllegalArgumentException("id es obligatorio");
        if (n.recipient() == null || n.recipient().isBlank()) throw new IllegalArgumentException("recipient es obligatorio");
        if (n.channel() == null || !n.channel().matches("SMS|EMAIL|PUSH")) throw new IllegalArgumentException("channel debe ser SMS, EMAIL o PUSH");
        if (n.message() == null || n.message().isBlank()) throw new IllegalArgumentException("message es obligatorio");
        exchange.getMessage().setHeader("notificationId", n.id());
        exchange.getMessage().setHeader("channel", n.channel());
        exchange.getMessage().setHeader("recipient", n.recipient());
        exchange.getMessage().setBody(body);
    }
}
