package py.ucom.notificador.route;

import org.apache.camel.builder.RouteBuilder;

public class DeliveryRoutes extends RouteBuilder {
    @Override
    public void configure() {
        from("jms:queue:notification.sms")
            .routeId("delivery-sms")
            .setHeader("deliveryStatus", constant("SENT"))
            .process(e -> System.out.println("[SMS] " + e.getMessage().getBody(String.class)))
            .to("sql:INSERT INTO notification_history(notification_id, channel, recipient, status, payload) VALUES (:#notificationId, 'SMS', :#recipient, 'SENT', :#body)");

        from("jms:queue:notification.email")
            .routeId("delivery-email")
            .setHeader("deliveryStatus", constant("SENT"))
            .process(e -> System.out.println("[EMAIL] " + e.getMessage().getBody(String.class)))
            .to("sql:INSERT INTO notification_history(notification_id, channel, recipient, status, payload) VALUES (:#notificationId, 'EMAIL', :#recipient, 'SENT', :#body)");

        from("jms:queue:notification.push")
            .routeId("delivery-push")
            .setHeader("deliveryStatus", constant("SENT"))
            .process(e -> System.out.println("[PUSH] " + e.getMessage().getBody(String.class)))
            .to("sql:INSERT INTO notification_history(notification_id, channel, recipient, status, payload) VALUES (:#notificationId, 'PUSH', :#recipient, 'SENT', :#body)");
    }
}
