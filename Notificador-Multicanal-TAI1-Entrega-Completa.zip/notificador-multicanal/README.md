# Trabajo Autónomo de Investigación 1
## Implementación de patrones de integración empresarial en arquitecturas modernas basadas en mensajería

**Proyecto:** Notificador de mensajes multicanal SMS, EMAIL y PUSH  
**Integrantes:** Reynaldo Nequi, Danny Ovelar, Emmanuel Rodriguez

## 1. Descripción
La solución implementa una plataforma de integración que recibe solicitudes de notificación y las distribuye de forma asíncrona hacia tres canales: SMS, EMAIL y PUSH. Apache Camel funciona como motor de integración, Apache ActiveMQ Artemis como broker JMS y PostgreSQL como almacenamiento del historial de procesamiento.

Los proveedores finales son simulados para que el proyecto pueda ejecutarse en un entorno académico local sin depender de servicios externos.

## 2. Stack
- Java 21
- Apache Camel 4.14.7
- Apache ActiveMQ Artemis 2.42.0 (Docker)
- JMS
- Gradle 9.6+
- JBang/Camel JBang como alternativa de ejecución exploratoria
- PostgreSQL 17
- Docker Compose

## 3. Arquitectura
```mermaid
flowchart LR
 A[Cliente HTTP] --> B[Apache Camel REST]
 B --> C[Validación]
 C --> D[(Artemis notification.input)]
 D --> E[Content-Based Router]
 E --> F[Translator SMS]
 E --> G[Translator EMAIL]
 E --> H[Translator PUSH]
 F --> I[(Artemis notification.sms)]
 G --> J[(Artemis notification.email)]
 H --> K[(Artemis notification.push)]
 I --> L[Proveedor SMS simulado]
 J --> M[Proveedor EMAIL simulado]
 K --> N[Proveedor PUSH simulado]
 L --> O[(PostgreSQL)]
 M --> O
 N --> O
 C -. inválido .-> P[(DLQ)]
 P --> O
```

## 4. Patrones EIP
1. **Message Channel:** las rutas intercambian mensajes mediante colas JMS.
2. **Point-to-Point Channel:** `notification.input` distribuye cada solicitud a un consumidor.
3. **Content-Based Router:** selecciona la ruta según `channel`.
4. **Message Translator:** transforma el mensaje general a un formato común para el canal de salida.
5. **Message Filter / validación:** rechaza mensajes que no cumplen el contrato mínimo.
6. **Dead Letter Channel:** los mensajes inválidos o no enrutable se colocan en `notification.dlq`.
7. **Event-driven asynchronous processing:** la recepción HTTP confirma aceptación y el procesamiento continúa por colas.

## 5. Requisitos previos
- JDK 21
- Gradle 9.6 o superior
- Docker Desktop
- Git

## 6. Ejecución
### 6.1 Levantar infraestructura
```bash
docker compose up -d
```
Verificar:
```bash
docker compose ps
```
Artemis Console: http://localhost:8161

### 6.2 Ejecutar aplicación
```bash
gradle clean test
./gradlew run
```
En Windows PowerShell puede utilizarse:
```powershell
gradle clean test
gradle run
```

## 7. Prueba HTTP
### SMS
```powershell
curl.exe -X POST http://localhost:8080/notifications `
  -H "Content-Type: application/json" `
  -d '{"id":"N-001","recipient":"0981123456","channel":"SMS","subject":"Aviso","message":"Su solicitud fue procesada."}'
```

### EMAIL
```powershell
curl.exe -X POST http://localhost:8080/notifications `
  -H "Content-Type: application/json" `
  -d '{"id":"N-002","recipient":"cliente@ejemplo.com","channel":"EMAIL","subject":"Confirmación","message":"Su operación fue confirmada."}'
```

### PUSH
```powershell
curl.exe -X POST http://localhost:8080/notifications `
  -H "Content-Type: application/json" `
  -d '{"id":"N-003","recipient":"device-123","channel":"PUSH","subject":"Alerta","message":"Tiene una nueva notificación."}'
```

## 8. Caso inválido
```powershell
curl.exe -X POST http://localhost:8080/notifications `
  -H "Content-Type: application/json" `
  -d '{"id":"N-004","recipient":"cliente","channel":"WHATSAPP","message":"Mensaje inválido"}'
```
Debe terminar como mensaje rechazado y dirigirse a la DLQ.

## 9. Persistencia
Consultar:
```sql
SELECT id, notification_id, channel, recipient, status, created_at
FROM notification_history
ORDER BY id DESC;
```

## 10. Evidencias recomendadas
Capturar:
1. `docker compose ps`.
2. Consola de Artemis mostrando las colas.
3. Terminal con Camel iniciado.
4. POST exitoso SMS.
5. POST exitoso EMAIL.
6. POST exitoso PUSH.
7. POST inválido y mensaje en DLQ.
8. Consulta de PostgreSQL mostrando el historial.

## 11. Estructura
```text
src/main/java/py/ucom/notificador/
├── Main.java
├── config/ApplicationConfiguration.java
├── model/Notification.java
├── processor/ValidationProcessor.java
├── processor/ChannelTranslator.java
└── route/
    ├── NotificationRoute.java
    ├── DeliveryRoutes.java
    └── ErrorRoute.java
```

## 12. Referencias
Hohpe, G., & Woolf, B. (2003). *Enterprise Integration Patterns: Designing, Building, and Deploying Messaging Solutions*. Addison-Wesley.

Enterprise Integration Patterns: https://www.enterpriseintegrationpatterns.com/
Apache Camel: https://camel.apache.org/
Apache ActiveMQ Artemis: https://activemq.apache.org/components/artemis/
